--
-- PostgreSQL database dump
--

-- Dumped from database version 12.0
-- Dumped by pg_dump version 12.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: f3kp; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA f3kp;


ALTER SCHEMA f3kp OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: f3kp_combination; Type: TABLE; Schema: f3kp; Owner: postgres
--

CREATE TABLE f3kp.f3kp_combination (
    id character(22) NOT NULL,
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    competition_task_id character(22),
    task_group_code character(1),
    pilot_id character(22),
    weight numeric,
    time_registred boolean,
    accept_times boolean
);


ALTER TABLE f3kp.f3kp_combination OWNER TO postgres;

--
-- Name: f3kp_competition; Type: TABLE; Schema: f3kp; Owner: postgres
--

CREATE TABLE f3kp.f3kp_competition (
    id character(22) NOT NULL,
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    name character varying(30),
    venue character varying(30),
    date date,
    state_code character(1)
);


ALTER TABLE f3kp.f3kp_competition OWNER TO postgres;

--
-- Name: f3kp_competition_task; Type: TABLE; Schema: f3kp; Owner: postgres
--

CREATE TABLE f3kp.f3kp_competition_task (
    id character(22) NOT NULL,
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    _row_count bigint,
    __ins_user text,
    competition_id character(22),
    task_code character varying(3),
    state_code character(1),
    number_groups bigint
);


ALTER TABLE f3kp.f3kp_competition_task OWNER TO postgres;

--
-- Name: f3kp_flight_time; Type: TABLE; Schema: f3kp; Owner: postgres
--

CREATE TABLE f3kp.f3kp_flight_time (
    id character(22) NOT NULL,
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    _row_count bigint,
    __ins_user text,
    combination_id character(22),
    flight_time numeric
);


ALTER TABLE f3kp.f3kp_flight_time OWNER TO postgres;

--
-- Name: f3kp_group; Type: TABLE; Schema: f3kp; Owner: postgres
--

CREATE TABLE f3kp.f3kp_group (
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    code character(1) NOT NULL,
    description text
);


ALTER TABLE f3kp.f3kp_group OWNER TO postgres;

--
-- Name: f3kp_pilot; Type: TABLE; Schema: f3kp; Owner: postgres
--

CREATE TABLE f3kp.f3kp_pilot (
    id character(22) NOT NULL,
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    first_name character varying(60),
    last_name character varying(60),
    fai_number character varying(15),
    other_regist_number character varying(15),
    fai_id character varying(15),
    pilot_class character varying(20),
    club character varying(60),
    street character varying(30),
    town character varying(30),
    state character varying(15),
    post_code character varying(8),
    country character(2),
    email character varying(60),
    private_phone character varying(18),
    work_phone character varying(18),
    user_id character(22)
);


ALTER TABLE f3kp.f3kp_pilot OWNER TO postgres;

--
-- Name: f3kp_registration; Type: TABLE; Schema: f3kp; Owner: postgres
--

CREATE TABLE f3kp.f3kp_registration (
    id character(22) NOT NULL,
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    _row_count bigint,
    __ins_user text,
    competition_id character(22),
    weight numeric,
    pilot_id character(22)
);


ALTER TABLE f3kp.f3kp_registration OWNER TO postgres;

--
-- Name: f3kp_state; Type: TABLE; Schema: f3kp; Owner: postgres
--

CREATE TABLE f3kp.f3kp_state (
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    code character(1) NOT NULL,
    description character varying(30)
);


ALTER TABLE f3kp.f3kp_state OWNER TO postgres;

--
-- Name: f3kp_task; Type: TABLE; Schema: f3kp; Owner: postgres
--

CREATE TABLE f3kp.f3kp_task (
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    code character varying(3) NOT NULL,
    description text,
    operative_time numeric
);


ALTER TABLE f3kp.f3kp_task OWNER TO postgres;

--
-- Name: f3kp_task_group; Type: TABLE; Schema: f3kp; Owner: postgres
--

CREATE TABLE f3kp.f3kp_task_group (
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    code character(1) NOT NULL,
    description text
);


ALTER TABLE f3kp.f3kp_task_group OWNER TO postgres;

--
-- Data for Name: f3kp_combination; Type: TABLE DATA; Schema: f3kp; Owner: postgres
--

COPY f3kp.f3kp_combination (id, __ins_ts, __del_ts, __mod_ts, __ins_user, competition_task_id, task_group_code, pilot_id, weight, time_registred, accept_times) FROM stdin;
\.


--
-- Data for Name: f3kp_competition; Type: TABLE DATA; Schema: f3kp; Owner: postgres
--

COPY f3kp.f3kp_competition (id, __ins_ts, __del_ts, __mod_ts, __ins_user, name, venue, date, state_code) FROM stdin;
\.


--
-- Data for Name: f3kp_competition_task; Type: TABLE DATA; Schema: f3kp; Owner: postgres
--

COPY f3kp.f3kp_competition_task (id, __ins_ts, __del_ts, __mod_ts, _row_count, __ins_user, competition_id, task_code, state_code, number_groups) FROM stdin;
\.


--
-- Data for Name: f3kp_flight_time; Type: TABLE DATA; Schema: f3kp; Owner: postgres
--

COPY f3kp.f3kp_flight_time (id, __ins_ts, __del_ts, __mod_ts, _row_count, __ins_user, combination_id, flight_time) FROM stdin;
\.


--
-- Data for Name: f3kp_group; Type: TABLE DATA; Schema: f3kp; Owner: postgres
--

COPY f3kp.f3kp_group (__ins_ts, __del_ts, __mod_ts, __ins_user, code, description) FROM stdin;
\.


--
-- Data for Name: f3kp_pilot; Type: TABLE DATA; Schema: f3kp; Owner: postgres
--

COPY f3kp.f3kp_pilot (id, __ins_ts, __del_ts, __mod_ts, __ins_user, first_name, last_name, fai_number, other_regist_number, fai_id, pilot_class, club, street, town, state, post_code, country, email, private_phone, work_phone, user_id) FROM stdin;
\.


--
-- Data for Name: f3kp_registration; Type: TABLE DATA; Schema: f3kp; Owner: postgres
--

COPY f3kp.f3kp_registration (id, __ins_ts, __del_ts, __mod_ts, _row_count, __ins_user, competition_id, weight, pilot_id) FROM stdin;
\.


--
-- Data for Name: f3kp_state; Type: TABLE DATA; Schema: f3kp; Owner: postgres
--

COPY f3kp.f3kp_state (__ins_ts, __del_ts, __mod_ts, __ins_user, code, description) FROM stdin;
2020-12-04 00:02:03.353046	\N	2020-12-04 00:02:03.353046	admin	S	STARTED
2020-12-04 00:02:03.407997	\N	2020-12-04 00:02:03.407997	admin	E	ENDED
2020-12-04 00:02:03.409552	\N	2020-12-04 00:02:03.409552	admin	P	PAUSED
2020-12-04 00:02:03.411126	\N	2020-12-04 00:02:03.411126	admin	A	APPROVED
2020-12-04 00:02:03.410444	\N	2020-12-04 00:02:24.895865	admin	T	TO BE APPROVE
\.


--
-- Data for Name: f3kp_task; Type: TABLE DATA; Schema: f3kp; Owner: postgres
--

COPY f3kp.f3kp_task (__ins_ts, __del_ts, __mod_ts, __ins_user, code, description, operative_time) FROM stdin;
2020-11-17 13:34:35.116793	\N	2020-11-17 13:34:35.116793	admin	C	TASK C - ALL UP, LAST DOWN  MAX 180 SECONDS FOR 3 TIMES	3
2020-11-06 19:50:03.444855	\N	2020-11-17 13:35:28.975861	admin	A	TASK A - LAST FLIGHT,  MAX 300 SECONDS O.T 10 MIN.	10
2020-11-06 19:50:48.581522	\N	2020-11-17 13:35:45.516771	admin	A2	TASK A - LAST FLIGHT,  MAX 300 SECONDS O.T 7 MIN.	7
2020-11-06 19:51:46.703164	\N	2020-11-17 13:48:30.213191	admin	B	TASK B - NEXT TO LAST AND LAST FLIGHT, MAX 240 SECONDS O.T.10 MIN.	10
2020-11-06 19:55:20.565935	\N	2020-11-17 13:48:30.221135	admin	B2	TASK B - NEXT TO LAST AND LAST FLIGHT, MAX 180 SECONDS O.T. 7MIN.	7
2020-11-17 13:57:02.768946	\N	2020-11-17 13:57:02.768946	admin	C2	TASK C - ALL UP, LAST DOWN  MAX 180 SECONDS FOR 5 TIMES	3
2020-11-17 13:59:17.22475	\N	2020-11-17 17:18:33.850556	admin	E	TASK E - POKER - VARIABLE TARGET TIME UP TO THREE TARGET TIMES O.T.10 MIN,	10
2020-11-17 13:59:17.171278	\N	2020-11-17 17:18:43.723594	admin	D	TASK D - TWO FLIGHTS MAX 300 SECONDS O.T. 10 MIN.	10
2020-11-17 17:20:54.483004	\N	2020-11-17 17:20:54.483004	admin	E2	TASK E - POKER - VARIABLE TARGET TIME UP TO THREE TARGET TIMES O.T.15 MIN,	15
2020-11-17 17:23:17.559543	\N	2020-11-17 17:23:17.559543	admin	F	TASK F - 3 OUT OF 6 MAX 180 SECONDS O.T. 10 MIN.	10
2020-11-17 17:24:31.155746	\N	2020-11-17 17:24:31.155746	admin	G	TASK G - FIVE LONGEST FLIGHTS, MAX 120 SECONDS O.T. 10 MIN.	10
2020-11-17 17:25:21.031266	\N	2020-11-17 17:25:21.031266	admin	H	TASK H - ONE, TWO, THREE AND FOUR MINUTE TARGET FLIGHT TIMES, ANY ORDER O.T. 10 MIN.	10
2020-11-17 17:26:41.852267	\N	2020-11-17 17:26:41.852267	admin	I	TASK I - THREE LONGEST FLIGHTS, MAX 200 SECONDS O.T. 10 MIN.	10
2020-11-17 17:27:55.739886	\N	2020-11-17 17:27:55.739886	admin	J	TASK J - THREE LAST FLIGHTS, MAX 180 SECONDS O.T 10 MIN.	10
2020-11-17 17:28:35.781299	\N	2020-11-17 17:28:35.781299	admin	K	TASK K - INCREASING TIME BY 30 SECONDS, “BIG LADDER” O.T. 10 MIN.	10
2020-11-17 17:29:47.474817	\N	2020-11-17 17:29:47.474817	admin	L	TASK L - ONE FLIGHT, MAX 599 SECONDS O.T 10 MIN.	10
2020-11-17 17:31:19.185462	\N	2020-11-17 17:31:19.185462	admin	M	FLY-OFF TASK M INCREASING TIME BY 2 MINUTES “HUGE LADDER” 3-5-7 MIN O.T. 15 MIN.	15
\.


--
-- Data for Name: f3kp_task_group; Type: TABLE DATA; Schema: f3kp; Owner: postgres
--

COPY f3kp.f3kp_task_group (__ins_ts, __del_ts, __mod_ts, __ins_user, code, description) FROM stdin;
2020-11-07 18:02:27.344272	\N	2020-11-07 18:02:27.344272	admin	1	A
2020-11-07 18:03:01.606578	\N	2020-11-07 18:03:01.606578	admin	2	B
2020-11-07 18:03:01.663425	\N	2020-11-07 18:03:01.663425	admin	3	C
2020-11-07 18:03:01.664424	\N	2020-11-07 18:03:01.664424	admin	4	D
2020-11-07 18:03:01.665419	\N	2020-11-07 18:03:01.665419	admin	5	E
2020-11-07 18:03:01.666417	\N	2020-11-07 18:03:01.666417	admin	6	F
2020-11-07 18:03:01.667414	\N	2020-11-07 18:03:01.667414	admin	7	G
2020-11-07 18:03:01.668411	\N	2020-11-07 18:03:01.668411	admin	8	H
\.


--
-- Name: f3kp_combination f3kp_combination_pkey; Type: CONSTRAINT; Schema: f3kp; Owner: postgres
--

ALTER TABLE ONLY f3kp.f3kp_combination
    ADD CONSTRAINT f3kp_combination_pkey PRIMARY KEY (id);


--
-- Name: f3kp_competition f3kp_competition_pkey; Type: CONSTRAINT; Schema: f3kp; Owner: postgres
--

ALTER TABLE ONLY f3kp.f3kp_competition
    ADD CONSTRAINT f3kp_competition_pkey PRIMARY KEY (id);


--
-- Name: f3kp_competition_task f3kp_competition_task_pkey; Type: CONSTRAINT; Schema: f3kp; Owner: postgres
--

ALTER TABLE ONLY f3kp.f3kp_competition_task
    ADD CONSTRAINT f3kp_competition_task_pkey PRIMARY KEY (id);


--
-- Name: f3kp_flight_time f3kp_flight_time_pkey; Type: CONSTRAINT; Schema: f3kp; Owner: postgres
--

ALTER TABLE ONLY f3kp.f3kp_flight_time
    ADD CONSTRAINT f3kp_flight_time_pkey PRIMARY KEY (id);


--
-- Name: f3kp_group f3kp_group_pkey; Type: CONSTRAINT; Schema: f3kp; Owner: postgres
--

ALTER TABLE ONLY f3kp.f3kp_group
    ADD CONSTRAINT f3kp_group_pkey PRIMARY KEY (code);


--
-- Name: f3kp_pilot f3kp_pilot_pkey; Type: CONSTRAINT; Schema: f3kp; Owner: postgres
--

ALTER TABLE ONLY f3kp.f3kp_pilot
    ADD CONSTRAINT f3kp_pilot_pkey PRIMARY KEY (id);


--
-- Name: f3kp_pilot f3kp_pilot_user_id_key; Type: CONSTRAINT; Schema: f3kp; Owner: postgres
--

ALTER TABLE ONLY f3kp.f3kp_pilot
    ADD CONSTRAINT f3kp_pilot_user_id_key UNIQUE (user_id);


--
-- Name: f3kp_registration f3kp_registration_pkey; Type: CONSTRAINT; Schema: f3kp; Owner: postgres
--

ALTER TABLE ONLY f3kp.f3kp_registration
    ADD CONSTRAINT f3kp_registration_pkey PRIMARY KEY (id);


--
-- Name: f3kp_state f3kp_state_pkey; Type: CONSTRAINT; Schema: f3kp; Owner: postgres
--

ALTER TABLE ONLY f3kp.f3kp_state
    ADD CONSTRAINT f3kp_state_pkey PRIMARY KEY (code);


--
-- Name: f3kp_task_group f3kp_task_group_pkey; Type: CONSTRAINT; Schema: f3kp; Owner: postgres
--

ALTER TABLE ONLY f3kp.f3kp_task_group
    ADD CONSTRAINT f3kp_task_group_pkey PRIMARY KEY (code);


--
-- Name: f3kp_task f3kp_task_pkey; Type: CONSTRAINT; Schema: f3kp; Owner: postgres
--

ALTER TABLE ONLY f3kp.f3kp_task
    ADD CONSTRAINT f3kp_task_pkey PRIMARY KEY (code);


--
-- Name: f3kp_combination___del_ts_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_combination___del_ts_idx ON f3kp.f3kp_combination USING btree (__del_ts);


--
-- Name: f3kp_combination___ins_ts_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_combination___ins_ts_idx ON f3kp.f3kp_combination USING btree (__ins_ts);


--
-- Name: f3kp_combination___mod_ts_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_combination___mod_ts_idx ON f3kp.f3kp_combination USING btree (__mod_ts);


--
-- Name: f3kp_combination_competition_task_id_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_combination_competition_task_id_idx ON f3kp.f3kp_combination USING btree (competition_task_id);


--
-- Name: f3kp_combination_pilot_id_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_combination_pilot_id_idx ON f3kp.f3kp_combination USING btree (pilot_id);


--
-- Name: f3kp_combination_task_group_code_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_combination_task_group_code_idx ON f3kp.f3kp_combination USING btree (task_group_code);


--
-- Name: f3kp_competition___del_ts_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_competition___del_ts_idx ON f3kp.f3kp_competition USING btree (__del_ts);


--
-- Name: f3kp_competition___ins_ts_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_competition___ins_ts_idx ON f3kp.f3kp_competition USING btree (__ins_ts);


--
-- Name: f3kp_competition___mod_ts_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_competition___mod_ts_idx ON f3kp.f3kp_competition USING btree (__mod_ts);


--
-- Name: f3kp_competition_state_code_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_competition_state_code_idx ON f3kp.f3kp_competition USING btree (state_code);


--
-- Name: f3kp_competition_task___del_ts_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_competition_task___del_ts_idx ON f3kp.f3kp_competition_task USING btree (__del_ts);


--
-- Name: f3kp_competition_task___ins_ts_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_competition_task___ins_ts_idx ON f3kp.f3kp_competition_task USING btree (__ins_ts);


--
-- Name: f3kp_competition_task___mod_ts_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_competition_task___mod_ts_idx ON f3kp.f3kp_competition_task USING btree (__mod_ts);


--
-- Name: f3kp_competition_task_competition_id_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_competition_task_competition_id_idx ON f3kp.f3kp_competition_task USING btree (competition_id);


--
-- Name: f3kp_competition_task_state_code_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_competition_task_state_code_idx ON f3kp.f3kp_competition_task USING btree (state_code);


--
-- Name: f3kp_competition_task_task_code_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_competition_task_task_code_idx ON f3kp.f3kp_competition_task USING btree (task_code);


--
-- Name: f3kp_flight_time___del_ts_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_flight_time___del_ts_idx ON f3kp.f3kp_flight_time USING btree (__del_ts);


--
-- Name: f3kp_flight_time___ins_ts_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_flight_time___ins_ts_idx ON f3kp.f3kp_flight_time USING btree (__ins_ts);


--
-- Name: f3kp_flight_time___mod_ts_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_flight_time___mod_ts_idx ON f3kp.f3kp_flight_time USING btree (__mod_ts);


--
-- Name: f3kp_flight_time_combination_id_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_flight_time_combination_id_idx ON f3kp.f3kp_flight_time USING btree (combination_id);


--
-- Name: f3kp_group___del_ts_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_group___del_ts_idx ON f3kp.f3kp_group USING btree (__del_ts);


--
-- Name: f3kp_group___ins_ts_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_group___ins_ts_idx ON f3kp.f3kp_group USING btree (__ins_ts);


--
-- Name: f3kp_group___mod_ts_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_group___mod_ts_idx ON f3kp.f3kp_group USING btree (__mod_ts);


--
-- Name: f3kp_pilot___del_ts_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_pilot___del_ts_idx ON f3kp.f3kp_pilot USING btree (__del_ts);


--
-- Name: f3kp_pilot___ins_ts_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_pilot___ins_ts_idx ON f3kp.f3kp_pilot USING btree (__ins_ts);


--
-- Name: f3kp_pilot___mod_ts_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_pilot___mod_ts_idx ON f3kp.f3kp_pilot USING btree (__mod_ts);


--
-- Name: f3kp_pilot_user_id_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE UNIQUE INDEX f3kp_pilot_user_id_idx ON f3kp.f3kp_pilot USING btree (user_id);


--
-- Name: f3kp_registration___del_ts_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_registration___del_ts_idx ON f3kp.f3kp_registration USING btree (__del_ts);


--
-- Name: f3kp_registration___ins_ts_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_registration___ins_ts_idx ON f3kp.f3kp_registration USING btree (__ins_ts);


--
-- Name: f3kp_registration___mod_ts_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_registration___mod_ts_idx ON f3kp.f3kp_registration USING btree (__mod_ts);


--
-- Name: f3kp_registration_competition_id_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_registration_competition_id_idx ON f3kp.f3kp_registration USING btree (competition_id);


--
-- Name: f3kp_registration_pilot_id_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_registration_pilot_id_idx ON f3kp.f3kp_registration USING btree (pilot_id);


--
-- Name: f3kp_state___del_ts_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_state___del_ts_idx ON f3kp.f3kp_state USING btree (__del_ts);


--
-- Name: f3kp_state___ins_ts_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_state___ins_ts_idx ON f3kp.f3kp_state USING btree (__ins_ts);


--
-- Name: f3kp_state___mod_ts_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_state___mod_ts_idx ON f3kp.f3kp_state USING btree (__mod_ts);


--
-- Name: f3kp_task___del_ts_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_task___del_ts_idx ON f3kp.f3kp_task USING btree (__del_ts);


--
-- Name: f3kp_task___ins_ts_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_task___ins_ts_idx ON f3kp.f3kp_task USING btree (__ins_ts);


--
-- Name: f3kp_task___mod_ts_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_task___mod_ts_idx ON f3kp.f3kp_task USING btree (__mod_ts);


--
-- Name: f3kp_task_group___del_ts_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_task_group___del_ts_idx ON f3kp.f3kp_task_group USING btree (__del_ts);


--
-- Name: f3kp_task_group___ins_ts_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_task_group___ins_ts_idx ON f3kp.f3kp_task_group USING btree (__ins_ts);


--
-- Name: f3kp_task_group___mod_ts_idx; Type: INDEX; Schema: f3kp; Owner: postgres
--

CREATE INDEX f3kp_task_group___mod_ts_idx ON f3kp.f3kp_task_group USING btree (__mod_ts);


--
-- Name: f3kp_pilot fk_f3kp_pilot_user_id; Type: FK CONSTRAINT; Schema: f3kp; Owner: postgres
--

ALTER TABLE ONLY f3kp.f3kp_pilot
    ADD CONSTRAINT fk_f3kp_pilot_user_id FOREIGN KEY (user_id) REFERENCES adm.adm_user(id) ON UPDATE CASCADE;


--
-- PostgreSQL database dump complete
--

